package fileRepo

import (
	"context"
	"fmt"
	"github.com/BobrePatre/Tech-Arrow/internal/models"
	"github.com/BobrePatre/Tech-Arrow/internal/repository"
	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
	"io"
	"log/slog"
	"os"
	"path/filepath"
)

var _ repository.FileRepository = (*Repository)(nil)

type Repository struct {
	db *sqlx.DB
}

func NewRepository(db *sqlx.DB) *Repository {
	return &Repository{
		db: db,
	}
}

func (r *Repository) SaveFileToStorage(_ context.Context, fileReader io.Reader, file models.File) error {
	if err := os.MkdirAll("files", os.ModePerm); err != nil {
		return fmt.Errorf("failed to create directory: %v", err)
	}

	// Create the file
	filePath := filepath.Join("files", fmt.Sprintf("%s.%s", file.Id, file.Metadata.FileExtention))
	newFile, err := os.Create(filePath)
	if err != nil {
		return fmt.Errorf("failed to create file: %v", err)
	}
	defer func(newFile *os.File) {
		err := newFile.Close()
		if err != nil {
			slog.Error("error with creating file")
		}
	}(newFile)

	// Copy data from the reader to the file
	_, err = io.Copy(newFile, fileReader)
	if err != nil {
		return fmt.Errorf("failed to write file data: %v", err)
	}

	return nil
}

func (r *Repository) SaveFileDataToDatabase(ctx context.Context, file models.File) error {
	tx, err := r.db.Beginx()
	if err != nil {
		slog.Error("errorr with creating transactions", "err", err.Error())
		return err
	}

	_, err = tx.ExecContext(ctx,
		"INSERT INTO files (id, file_id, owner_id) VALUES ($1, $2, $3)",
		file.Id,
		file.Id,
		file.OwnerId,
	)
	if err != nil {
		if err := tx.Rollback(); err != nil {
			return err
		}
		return err
	}

	_, err = tx.ExecContext(ctx, "INSERT INTO files_metadata (id, file_id, size, file_type, file_extention) VALUES ($1, $2, $3, $4, $5 )",
		file.Metadata.Id,
		file.Id,
		file.Metadata.Size,
		file.Metadata.FileType,
		file.Metadata.FileExtention,
	)
	if err != nil {
		if err := tx.Rollback(); err != nil {
			return err
		}
		return err
	}

	err = tx.Commit()
	if err != nil {
		return err
	}
	return nil
}

func (r *Repository) GetFileInfo(ctx context.Context, fileId string) (*models.File, error) {
	var file RecordFile
	var fileMetadata RecordMetadata

	tx, err := r.db.Beginx()
	if err != nil {
		return nil, err
	}

	err = tx.GetContext(ctx, &file, "SELECT * FROM files WHERE file_id = $1", fileId)
	if err != nil {
		if err := tx.Rollback(); err != nil {
			return nil, err
		}
		return nil, err
	}

	err = tx.GetContext(ctx, &fileMetadata, "SELECT * FROM files_metadata WHERE file_id = $1", fileId)
	if err != nil {
		if err := tx.Rollback(); err != nil {
			return nil, err
		}
		return nil, err
	}

	err = tx.Commit()
	if err != nil {
		return nil, err
	}

	file.Metadata = &fileMetadata

	resultDomain := FileToModelFromRepo(file)
	return resultDomain, nil

}

func (r *Repository) GetFilesByOwnerId(ctx context.Context, ownerId string) (*[]models.File, error) {
	var files []RecordFile
	tx, err := r.db.Beginx()
	if err != nil {
		slog.Error("errorr with creating transactions", "err", err.Error())
		return nil, err
	}

	err = tx.Select(&files, "SELECT * FROM files WHERE owner_id = $1", ownerId)
	if err != nil {
		if err := tx.Rollback(); err != nil {
			return nil, err
		}
		return nil, err
	}

	for i, f := range files {
		var fileMetadata RecordMetadata
		err = tx.Get(&fileMetadata, "SELECT * FROM files_metadata WHERE file_id = $1", f.FileId)
		if err != nil {
			slog.Error("Error while getting file metadata", "err", err.Error())
			continue
		}
		slog.Debug("file metadata", "metadata", fileMetadata)
		files[i].Metadata = &fileMetadata
	}
	slog.Debug("files", "files", files)
	result := FileSliceToModelFromRepo(files)
	slog.Debug("result", "result", result)
	return result, nil
}

func (r *Repository) GetFilesByAlbumId(ctx context.Context, albumId string) (*[]models.File, error) {
	var files []RecordFile
	tx, err := r.db.Beginx()
	if err != nil {
		slog.Error("errorr with creating transactions", "err", err.Error())
		return nil, err
	}

	err = tx.Select(&files, `
		SELECT f.id, f.owner_id
		FROM file_album fa
		INNER JOIN files f ON fa.file_id = f.id
		WHERE fa.album_id = $1`, albumId)
	if err != nil {
		if err := tx.Rollback(); err != nil {
			return nil, err
		}
		return nil, err
	}

	for i, f := range files {
		slog.Debug("file  in getting metadata", "file", f)
		var fileMetadata RecordMetadata
		err = tx.Get(&fileMetadata, "SELECT * FROM files_metadata WHERE file_id = $1", f.Id)
		if err != nil {
			slog.Error("Error while getting file metadata", "err", err.Error())
			continue
		}
		slog.Debug("file metadata", "metadata", fileMetadata)
		files[i].Metadata = &fileMetadata
	}
	slog.Debug("files", "files", files)
	result := FileSliceToModelFromRepo(files)
	slog.Debug("result", "result", result)
	return result, nil
}

func (r *Repository) AddFileToAlbum(ctx context.Context, albumId string, fileId string) error {
	tx, err := r.db.Beginx()
	if err != nil {
		slog.Error("errorr with creating transactions", "err", err.Error())
		return err
	}

	_, err = tx.ExecContext(ctx, "INSERT INTO file_album (id, file_id, album_id) VALUES ($1, $2, $3)", uuid.NewString(), fileId, albumId)
	if err != nil {
		return err
	}

	err = tx.Commit()
	if err != nil {
		return err
	}
	return nil
}
