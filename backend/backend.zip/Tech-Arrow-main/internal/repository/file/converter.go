package fileRepo

import "github.com/BobrePatre/Tech-Arrow/internal/models"

func FileSliceToModelFromRepo(files []RecordFile) *[]models.File {
	var result []models.File
	for _, f := range files {
		result = append(result, *FileToModelFromRepo(f))
	}
	return &result
}

func FileToModelFromRepo(file RecordFile) *models.File {

	return &models.File{
		Id:       file.Id,
		OwnerId:  file.OwnerId,
		Metadata: MetadataToModelFromRepo(file.Metadata),
	}
}

func MetadataToModelFromRepo(metadata *RecordMetadata) *models.FileMetadata {
	return &models.FileMetadata{
		Id:            metadata.Id,
		Size:          metadata.Size,
		FileType:      metadata.FileType,
		FileExtention: metadata.FileExtention,
	}
}
