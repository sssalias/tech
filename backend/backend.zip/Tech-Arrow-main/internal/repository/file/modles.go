package fileRepo

type (
	RecordFile struct {
		Id       string `db:"id"`
		FileId   string `db:"file_id"`
		OwnerId  string `db:"owner_id"`
		Metadata *RecordMetadata
	}

	RecordMetadata struct {
		Id            string `db:"id"`
		FileId        string `db:"file_id"`
		Size          int64  `db:"size"`
		FileType      string `db:"file_type"`
		FileExtention string `db:"file_extention"`
	}
)
