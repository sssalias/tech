package albumRepo

import "github.com/BobrePatre/Tech-Arrow/internal/models"

func SliceAlbumsToDomainFromRepo(albums []RecordAlbum) *[]models.Album {
	var result []models.Album
	for _, album := range albums {
		result = append(result, *AlbumToDomainFromRepo(&album))
	}

	return &result
}

func AlbumToDomainFromRepo(albumRecord *RecordAlbum) *models.Album {
	return &models.Album{
		Id:        albumRecord.Id,
		Title:     albumRecord.Title,
		OwnerId:   albumRecord.OwnerId,
		PreviewId: albumRecord.PreviewId,
	}

}
