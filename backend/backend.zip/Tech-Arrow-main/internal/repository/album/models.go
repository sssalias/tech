package albumRepo

type (
	RecordAlbum struct {
		Id        string  `db:"id"`
		Title     string  `db:"title"`
		OwnerId   string  `db:"owner_id"`
		PreviewId *string `db:"preview_id"`
	}
)
