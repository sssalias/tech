package albumRepo

import (
	"context"
	"github.com/BobrePatre/Tech-Arrow/internal/models"
	"github.com/BobrePatre/Tech-Arrow/internal/repository"
	"github.com/jmoiron/sqlx"
	"log/slog"
)

var _ repository.AlbumRepository = (*Repository)(nil)

type Repository struct {
	db *sqlx.DB
}

func NewRepository(db *sqlx.DB) *Repository {
	return &Repository{
		db: db,
	}
}

func (r Repository) CreateAlbum(ctx context.Context, album models.Album) error {
	tx, err := r.db.Beginx()
	if err != nil {
		slog.Error("errorr with creating transactions", "err", err.Error())
		return err
	}

	slog.Debug("album", "data", album)
	_, err = tx.ExecContext(ctx, "INSERT INTO album (id, title, owner_id, preview_id) VALUES ($1, $2, $3, $4)",
		album.Id,
		album.Title,
		album.OwnerId,
		album.PreviewId,
	)
	if err != nil {
		if err := tx.Rollback(); err != nil {
			return err
		}
		return err
	}

	err = tx.Commit()
	if err != nil {
		return err
	}
	return nil
}

func (r Repository) GetUserAlbums(ctx context.Context, ownerId string) (*[]models.Album, error) {
	var albums []RecordAlbum

	tx, err := r.db.Beginx()
	if err != nil {
		return nil, err
	}

	err = tx.SelectContext(ctx, &albums, "SELECT * FROM album WHERE owner_id = $1", ownerId)
	if err != nil {
		if err := tx.Rollback(); err != nil {

		}
		return nil, err
	}

	result := SliceAlbumsToDomainFromRepo(albums)
	return result, nil

}

func (r Repository) UpdateAlbum(ctx context.Context, album models.Album) error {
	tx, err := r.db.Beginx()
	if err != nil {
		return err
	}

	_, err = tx.ExecContext(ctx, "UPDATE album SET title = $1, preview_id = $2 WHERE owner_id = $3",
		album.Title,
		album.PreviewId,
		album.OwnerId,
	)
	if err != nil {
		if err := tx.Rollback(); err != nil {
			return err
		}
		return err
	}

	return nil
}

func (r Repository) DeleteAlbum(ctx context.Context, albumId string) error {
	tx, err := r.db.Beginx()
	if err != nil {
		return err
	}

	_, err = tx.ExecContext(ctx, "DELETE FROM album WHERE id = $1", albumId)
	if err != nil {
		if err := tx.Rollback(); err != nil {
			return err
		}
		return err
	}

	return nil
}
