package repository

import (
	"context"
	"github.com/BobrePatre/Tech-Arrow/internal/models"
	"io"
)

type (
	FileRepository interface {
		SaveFileToStorage(ctx context.Context, fileReader io.Reader, file models.File) error
		SaveFileDataToDatabase(ctx context.Context, file models.File) error
		GetFileInfo(ctx context.Context, fileId string) (*models.File, error)
		GetFilesByOwnerId(ctx context.Context, ownerId string) (*[]models.File, error)
		GetFilesByAlbumId(ctx context.Context, albumId string) (*[]models.File, error)
		AddFileToAlbum(ctx context.Context, albumId string, fileId string) error
	}

	AlbumRepository interface {
		CreateAlbum(ctx context.Context, album models.Album) error
		UpdateAlbum(ctx context.Context, album models.Album) error
		DeleteAlbum(ctx context.Context, albumId string) error
		GetUserAlbums(ctx context.Context, ownerId string) (*[]models.Album, error)
	}
)
