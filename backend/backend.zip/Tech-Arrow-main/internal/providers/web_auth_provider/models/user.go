package models

type UserDetails struct {
	Roles      []string
	UserId     string
	Email      string
	Username   string
	Name       string
	FamilyName string
}
