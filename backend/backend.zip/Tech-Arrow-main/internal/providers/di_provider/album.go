package diProvider

import (
	albumHandlers "github.com/BobrePatre/Tech-Arrow/internal/api/http/handlers/album"
	"github.com/BobrePatre/Tech-Arrow/internal/repository"
	albumRepo "github.com/BobrePatre/Tech-Arrow/internal/repository/album"
	"github.com/BobrePatre/Tech-Arrow/internal/service"
	albumService "github.com/BobrePatre/Tech-Arrow/internal/service/album"
)

func (p *DiProvider) AlbumRepository() repository.AlbumRepository {
	if p.albumRepository == nil {
		p.albumRepository = albumRepo.NewRepository(p.SqlDatabase())
	}
	return p.albumRepository
}

func (p *DiProvider) AlbumService() service.AlbumService {
	if p.albumService == nil {
		p.albumService = albumService.NewService(p.AlbumRepository(), p.FileRepository())
	}
	return p.albumService
}

func (p *DiProvider) AlbumHandler() *albumHandlers.Handler {
	if p.albumHandler == nil {
		p.albumHandler = albumHandlers.NewHandler(p.AlbumService(), p.Validate())
	}
	return p.albumHandler
}
