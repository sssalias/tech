package diProvider

import (
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/handlers/file"
	"github.com/BobrePatre/Tech-Arrow/internal/repository"
	fileRepository "github.com/BobrePatre/Tech-Arrow/internal/repository/file"
	"github.com/BobrePatre/Tech-Arrow/internal/service"
	fileService "github.com/BobrePatre/Tech-Arrow/internal/service/file"
)

func (p *DiProvider) FileRepository() repository.FileRepository {
	if p.fileRepository == nil {
		p.fileRepository = fileRepository.NewRepository(p.SqlDatabase())
	}
	return p.fileRepository
}

func (p *DiProvider) FileService() service.FileService {
	if p.fileService == nil {
		p.fileService = fileService.NewService(p.FileRepository())
	}
	return p.fileService
}

func (p *DiProvider) FileHandler() *fileHandlers.Handler {
	if p.fileHandler == nil {
		p.fileHandler = fileHandlers.NewHandler(p.FileService(), p.Validate())
	}
	return p.fileHandler
}
