package diProvider

import (
	albumHandlers "github.com/BobrePatre/Tech-Arrow/internal/api/http/handlers/album"
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/handlers/file"
	"github.com/BobrePatre/Tech-Arrow/internal/config"
	webAuthProvider "github.com/BobrePatre/Tech-Arrow/internal/providers/web_auth_provider"
	"github.com/BobrePatre/Tech-Arrow/internal/repository"
	"github.com/BobrePatre/Tech-Arrow/internal/service"
	"github.com/go-playground/validator/v10"
	"github.com/jmoiron/sqlx"
	"github.com/redis/go-redis/v9"
)

type DiProvider struct {
	redisClient *redis.Client
	redisConfig *config.RedisConfig

	sqlDatabase      *sqlx.DB
	postgresqlConfig *config.PostgresqlConfig

	validate *validator.Validate

	httpConfig *config.HttpConfig
	appConfig  *config.AppConfig

	webAuthProvider webAuthProvider.WebAuthProvider
	webAuthConfig   *config.WebAuthConfig

	httpAuthMiddlewareConstructor webAuthProvider.AuthHttpMiddlewareConstructor

	fileHandler    *fileHandlers.Handler
	fileService    service.FileService
	fileRepository repository.FileRepository

	albumHandler    *albumHandlers.Handler
	albumService    service.AlbumService
	albumRepository repository.AlbumRepository
}

func NewDiProvider() *DiProvider {
	return &DiProvider{}
}
