package fileService

import (
	"context"
	"fmt"
	"github.com/BobrePatre/Tech-Arrow/internal/models"
	"github.com/BobrePatre/Tech-Arrow/internal/repository"
	"github.com/BobrePatre/Tech-Arrow/internal/service"
	"github.com/google/uuid"
	"io"
	"log/slog"
	"os"
)

var _ service.FileService = (*Service)(nil)

const (
	fileFolder = "files"
)

var (
	allowedContentTypes = []string{"image/png", "image/jpeg", "video/mpeg", "video/quicktime", "video/mp4", "image/x-raw", "image/x-adobe-dng"}
)

func checkAllowedContentType(contentType string) bool {
	for _, allowedContentType := range allowedContentTypes {
		if allowedContentType == contentType {
			return true
		}
	}
	slog.Debug("file to fuck up", "file", contentType)
	return false
}

type Service struct {
	repository repository.FileRepository
}

func NewService(
	fileRepository repository.FileRepository,
) *Service {
	return &Service{
		repository: fileRepository,
	}
}

func (s *Service) CreateFile(ctx context.Context, file models.File, fileReader io.Reader) (*models.File, error) {

	if !checkAllowedContentType(file.Metadata.FileType) {
		return nil, models.NotAllowedContentTypeError
	}

	file.Id = uuid.NewString()
	file.Metadata.Id = uuid.NewString()

	err := s.repository.SaveFileToStorage(ctx, fileReader, file)
	if err != nil {
		return nil, err
	}

	err = s.repository.SaveFileDataToDatabase(ctx, file)
	if err != nil {
		return nil, err
	}

	slog.Debug("file", "file", file)
	return &file, err
}

func (s *Service) DownloadFile(ctx context.Context, fileId string) (fileReader io.Reader, fileInfo *models.File, err error) {

	fileInfo, err = s.repository.GetFileInfo(ctx, fileId)
	if err != nil {
		slog.Debug("file err", "fileErr", err)
		return nil, nil, err
	}

	slog.Debug("file Info", "fileInfo", fileInfo)
	fileReader, err = os.Open(fmt.Sprintf("%s/%s.%s", fileFolder, fileInfo.Id, fileInfo.Metadata.FileExtention))
	if err != nil {
		return nil, nil, err
	}

	return fileReader, fileInfo, nil
}

func (s *Service) GetFilesByOwnerId(ctx context.Context, ownerId string) (*[]models.File, error) {
	files, err := s.repository.GetFilesByOwnerId(ctx, ownerId)
	if err != nil {
		return nil, err
	}
	slog.Debug("files from service", "files", files)
	return files, nil
}

func (s *Service) AddFileToAlbum(ctx context.Context, fileId string, albumId string) error {
	err := s.repository.AddFileToAlbum(ctx, albumId, fileId)
	return err
}
