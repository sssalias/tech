package albumService

import (
	"context"
	"github.com/BobrePatre/Tech-Arrow/internal/models"
	"github.com/BobrePatre/Tech-Arrow/internal/repository"
	"github.com/BobrePatre/Tech-Arrow/internal/service"
	"github.com/google/uuid"
)

var _ service.AlbumService = (*Service)(nil)

type Service struct {
	albumRepository repository.AlbumRepository
	fileRepository  repository.FileRepository
}

func NewService(
	albumRepository repository.AlbumRepository,
	fileRepository repository.FileRepository,
) *Service {
	return &Service{
		albumRepository: albumRepository,
		fileRepository:  fileRepository,
	}
}

func (s Service) CreateAlbum(ctx context.Context, album models.Album) (*models.Album, error) {

	album.Id = uuid.NewString()
	err := s.albumRepository.CreateAlbum(ctx, album)
	if err != nil {
		return nil, err
	}

	return &album, nil
}

func (s Service) UpdateeAlbum(ctx context.Context, album models.Album) error {
	err := s.albumRepository.UpdateAlbum(ctx, album)
	return err
}

func (s Service) GetUserAlbums(ctx context.Context, ownerId string) (*[]models.Album, error) {
	userAlbums, err := s.albumRepository.GetUserAlbums(ctx, ownerId)
	if err != nil {
		return nil, err
	}

	for i, album := range *userAlbums {
		files, err := s.fileRepository.GetFilesByAlbumId(ctx, album.Id)
		if err != nil {
			return nil, err
		}
		(*userAlbums)[i].Files = *files
	}

	if err != nil {
		return nil, err
	}
	return userAlbums, nil
}

func (s Service) DeleteAlbum(ctx context.Context, albumId string) error {

	err := s.albumRepository.DeleteAlbum(ctx, albumId)
	return err
}
