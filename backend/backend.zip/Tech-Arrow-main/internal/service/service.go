package service

import (
	"context"
	"github.com/BobrePatre/Tech-Arrow/internal/models"
	"io"
)

type (
	FileService interface {
		CreateFile(ctx context.Context, fileIn models.File, fileData io.Reader) (fileInfo *models.File, err error)
		DownloadFile(ctx context.Context, fileId string) (fileReader io.Reader, fileInfo *models.File, err error)
		GetFilesByOwnerId(ctx context.Context, ownerId string) (*[]models.File, error)
		AddFileToAlbum(ctx context.Context, fileId string, albumId string) error
	}

	AlbumService interface {
		CreateAlbum(ctx context.Context, album models.Album) (*models.Album, error)
		UpdateeAlbum(ctx context.Context, album models.Album) error
		GetUserAlbums(ctx context.Context, ownerId string) (*[]models.Album, error)
		DeleteAlbum(ctx context.Context, albumId string) error
	}
)
