package models

type (
	File struct {
		Id       string
		OwnerId  string
		Metadata *FileMetadata
	}

	FileMetadata struct {
		Id            string
		Size          int64
		FileType      string
		FileExtention string
		Tags          []Tag
	}

	Tag struct {
		Id     string
		Tag    string
		FileId string
	}
)
