package models

import "fmt"

var (
	NotAllowedContentTypeError = fmt.Errorf("content type not allowed")
)
