package models

type (
	Album struct {
		Id        string
		Title     string
		OwnerId   string
		PreviewId *string
		Files     []File
	}
)
