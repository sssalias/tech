package app

import (
	"context"
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/middlewares"
	albumRoutes "github.com/BobrePatre/Tech-Arrow/internal/api/http/routes/album"
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/routes/file"
	"github.com/BobrePatre/Tech-Arrow/internal/constants"
	"github.com/gin-gonic/gin"
	"log/slog"
	"net/http"
)

var _ = (*App)(nil)

func (a *App) initHTTPServer(_ context.Context) error {

	switch a.diProvider.AppConfig().ENV {
	case constants.EnvDevelopment:
		gin.SetMode(gin.DebugMode)
	case constants.EnvProduction:
		gin.SetMode(gin.ReleaseMode)
	}

	router := gin.New()
	router.MaxMultipartMemory = 1 << 30

	router.Use(gin.Recovery())
	router.Use(middlewares.SlogLoggerMiddleware())
	router.Use(middlewares.CORSMiddleware())

	authMiddlewareConstructor := a.diProvider.HttpAuthMiddlewareConstructor()

	v1RouterGroup := router.Group("/api/v1", middlewares.CORSMiddleware())

	fileRoutes.NewRouter(
		v1RouterGroup,
		authMiddlewareConstructor(a.diProvider.WebAuthProvider()),
		a.diProvider.FileHandler(),
	).RegisterRoutes()

	albumRoutes.NewRouter(
		v1RouterGroup,
		authMiddlewareConstructor(a.diProvider.WebAuthProvider()),
		a.diProvider.AlbumHandler(),
	).RegisterRoutes()

	a.httpServer = &http.Server{
		Addr:    a.diProvider.HTTPConfig().Address(),
		Handler: router,
	}
	return nil
}

func (a *App) runHTTPServer() error {
	slog.Info(
		startingMsg,
		httpServerTag,
		slog.String(addressMsg, a.diProvider.HTTPConfig().Address()),
	)
	return a.httpServer.ListenAndServe()
}
