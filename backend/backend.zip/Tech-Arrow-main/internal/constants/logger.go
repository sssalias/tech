package constants

const (
	LoggerCategoryMiddlewares = "cors"
	LoggerCategoryHTTP        = "http"
	LoggerCategoryGRPC        = "grpc"
	LoggerCategoryDB          = "db"
	LoggerCategoryMisc        = "misc"
)
