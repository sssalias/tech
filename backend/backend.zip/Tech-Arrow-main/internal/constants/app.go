package constants

const (
	EnvDevelopment = "development"
	EnvProduction  = "production"
)
