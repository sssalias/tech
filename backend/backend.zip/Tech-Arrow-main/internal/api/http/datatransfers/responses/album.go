package responses

type (
	AlbumResponse struct {
		Id        string          `json:"id"`
		Title     string          `json:"title"`
		OwnerId   string          `json:"ownerId"`
		PreviewId *string         `json:"previewId"`
		Files     *[]FileResponse `json:"files,omitempty"`
	}
)
