package responses

type (
	FileResponse struct {
		Id       string        `json:"id"`
		OwnerId  string        `json:"ownerId"`
		Metadata *FileMetadata `json:"metadata"`
	}

	FileMetadata struct {
		Id            string    `json:"id"`
		Size          int64     `json:"size"`
		FileType      string    `json:"fileType"`
		FileExtention string    `json:"fileExtention"`
		Tags          []FileTag `json:"tags"`
	}

	FileTag struct {
		Id  string `json:"id"`
		Tag string `json:"tag"`
	}
)
