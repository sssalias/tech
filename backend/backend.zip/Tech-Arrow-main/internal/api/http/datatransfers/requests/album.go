package requests

type (
	CreateAlbum struct {
		Title     string  `json:"title" binding:"required"`
		PreviewId *string `json:"previewId" binding:"omitempty,uuid4"`
	}
)
