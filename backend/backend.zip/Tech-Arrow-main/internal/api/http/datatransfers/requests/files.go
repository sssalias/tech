package requests

import "mime/multipart"

type (
	UploadFileRequest struct {
		File *multipart.FileHeader `form:"file" binding:"required"`
	}

	DownloadFileRequest struct {
		FileId string `uri:"file-id" binding:"uuid4,required"`
	}

	AddFileToAlbumRequest struct {
		FileId  string `json:"fileId" binding:"uuid4,required"`
		AlbumId string `json:"albumId" binding:"uuid4,required"`
	}
)
