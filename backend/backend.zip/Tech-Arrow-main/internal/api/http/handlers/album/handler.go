package albumHandlers

import (
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/converters"
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/datatransfers/requests"
	webAuthProvider "github.com/BobrePatre/Tech-Arrow/internal/providers/web_auth_provider"
	authModels "github.com/BobrePatre/Tech-Arrow/internal/providers/web_auth_provider/models"
	"github.com/BobrePatre/Tech-Arrow/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
)

type Handler struct {
	service  service.AlbumService
	validate *validator.Validate
}

func NewHandler(
	service service.AlbumService,
	validate *validator.Validate,
) *Handler {
	return &Handler{
		service:  service,
		validate: validate,
	}
}

func (h *Handler) CreateAlbum(ctx *gin.Context) {
	var request requests.CreateAlbum

	if err := ctx.ShouldBind(&request); err != nil {
		ctx.AbortWithStatus(500)
		return
	}

	userDetails := ctx.Value(webAuthProvider.UserDetailsKey).(authModels.UserDetails)

	domainIn := converters.AlbumToDomainFromRequest(request)
	domainIn.OwnerId = userDetails.UserId
	album, err := h.service.CreateAlbum(ctx, domainIn)
	if err != nil {
		ctx.AbortWithStatusJSON(500, gin.H{"error": err.Error()})
		return
	}

	response := converters.AlbumToResponseFromDomain(*album)
	ctx.JSON(200, response)
}

func (h *Handler) GetUserAlbums(ctx *gin.Context) {

	userDetails := ctx.Value(webAuthProvider.UserDetailsKey).(authModels.UserDetails)

	result, err := h.service.GetUserAlbums(ctx, userDetails.UserId)
	if err != nil {
		ctx.AbortWithStatusJSON(500, gin.H{"error": err.Error()})
		return
	}

	response := converters.AlbumSliceToResponseFromDomain(*result)
	ctx.JSON(200, response)
}

func (h *Handler) DeleteAlbum(ctx *gin.Context) {

}
