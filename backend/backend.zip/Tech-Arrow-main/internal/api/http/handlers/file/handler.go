package fileHandlers

import (
	"errors"
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/converters"
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/datatransfers/requests"
	"github.com/BobrePatre/Tech-Arrow/internal/models"
	authProvider "github.com/BobrePatre/Tech-Arrow/internal/providers/web_auth_provider"
	authModels "github.com/BobrePatre/Tech-Arrow/internal/providers/web_auth_provider/models"
	"github.com/BobrePatre/Tech-Arrow/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
	"io"
	"log/slog"
	"mime/multipart"
	"strings"
)

type Handler struct {
	service  service.FileService
	validate *validator.Validate
}

func NewHandler(
	service service.FileService,
	validate *validator.Validate,
) *Handler {
	return &Handler{
		service:  service,
		validate: validate,
	}
}

func (h *Handler) Upload(ctx *gin.Context) {

	var request requests.UploadFileRequest
	if err := ctx.ShouldBind(&request); err != nil {
		ctx.AbortWithStatus(400)
		return
	}

	userDetails := ctx.Value(authProvider.UserDetailsKey).(authModels.UserDetails)

	splitedFileName := strings.Split(request.File.Filename, ".")
	fileExtention := splitedFileName[len(splitedFileName)-1]

	domainIn := models.File{
		OwnerId: userDetails.UserId,
		Metadata: &models.FileMetadata{
			Size:          request.File.Size,
			FileType:      request.File.Header.Get("Content-Type"),
			FileExtention: fileExtention,
		},
	}

	fileReader, err := request.File.Open()
	defer func(fileReader multipart.File) {
		err := fileReader.Close()
		if err != nil {
			slog.Error("error while closing fileReader", "err", err)
		}
	}(fileReader)
	if err != nil {
		ctx.AbortWithStatusJSON(500, "cannot read file data")
		return
	}
	fileInfo, err := h.service.CreateFile(ctx, domainIn, fileReader)
	if err != nil {
		switch {
		case errors.Is(err, models.NotAllowedContentTypeError):
			ctx.AbortWithStatusJSON(400, gin.H{"error": err.Error()})
		default:
			ctx.AbortWithStatusJSON(500, gin.H{"error": err.Error()})
		}
		return
	}

	response := converters.FileToResponseFromDomain(fileInfo)
	response.Metadata = converters.MetadataToReponseFromDomain(*fileInfo.Metadata)
	ctx.JSON(200, response)

}

func (h *Handler) Download(ctx *gin.Context) {
	var request requests.DownloadFileRequest

	if err := ctx.ShouldBindUri(&request); err != nil {
		slog.Debug("cannot validate request", "error", err, "field", request)
		ctx.AbortWithStatusJSON(400, gin.H{"error": err.Error()})
		return
	}

	fileReader, fileInfo, err := h.service.DownloadFile(ctx, request.FileId)
	if err != nil {
		ctx.AbortWithStatus(500)
		return
	}

	readedFile, err := io.ReadAll(fileReader)
	if err != nil {
		ctx.AbortWithStatusJSON(500, gin.H{"error": "cannot read file from storage"})

	}

	ctx.Data(200, fileInfo.Metadata.FileType, readedFile)
}

func (h *Handler) GetUserFiles(ctx *gin.Context) {

	userDetails := ctx.Value(authProvider.UserDetailsKey).(authModels.UserDetails)

	files, err := h.service.GetFilesByOwnerId(ctx, userDetails.UserId)
	if err != nil {
		ctx.AbortWithStatusJSON(500, gin.H{"err": err.Error()})
		return
	}
	response := converters.FileSliceToResponseFromDomain(files)
	slog.Debug("RESPONSE", "resp", response)
	ctx.JSON(200, response)
}

func (h *Handler) AddFileToAlbum(ctx *gin.Context) {
	var request requests.AddFileToAlbumRequest
	if err := ctx.ShouldBind(&request); err != nil {
		ctx.AbortWithStatusJSON(400, gin.H{"error": err.Error()})
		return
	}

	err := h.service.AddFileToAlbum(ctx, request.FileId, request.AlbumId)
	if err != nil {
		ctx.AbortWithStatusJSON(500, gin.H{"error": err.Error()})
		return
	}

	ctx.Status(200)
}
