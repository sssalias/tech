package fileRoutes

import (
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/handlers/file"
	authProvider "github.com/BobrePatre/Tech-Arrow/internal/providers/web_auth_provider"
	"github.com/gin-gonic/gin"
)

type Router struct {
	router         *gin.RouterGroup
	authMiddleware authProvider.AuthHttpMiddleware
	handler        *fileHandlers.Handler
}

func NewRouter(
	router *gin.RouterGroup,
	authMiddleware authProvider.AuthHttpMiddleware,
	handler *fileHandlers.Handler,
) *Router {
	return &Router{
		router:         router,
		authMiddleware: authMiddleware,
		handler:        handler,
	}
}

func (r *Router) RegisterRoutes() {
	routerGroup := r.router.Group("/files")
	{
		routerGroup.POST("", r.authMiddleware(), r.handler.Upload)
		routerGroup.GET("/:file-id", r.handler.Download)
		routerGroup.GET("/my", r.authMiddleware(), r.handler.GetUserFiles)
		routerGroup.POST("/add/to/album", r.authMiddleware(), r.handler.AddFileToAlbum)
	}
}
