package converters

import (
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/datatransfers/requests"
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/datatransfers/responses"
	"github.com/BobrePatre/Tech-Arrow/internal/models"
)

func AlbumToDomainFromRequest(album requests.CreateAlbum) models.Album {
	return models.Album{
		Title:     album.Title,
		PreviewId: album.PreviewId,
	}
}

func AlbumSliceToResponseFromDomain(albumsDomain []models.Album) []responses.AlbumResponse {
	var result []responses.AlbumResponse
	for _, albumsDomain := range albumsDomain {
		result = append(result, AlbumToResponseFromDomain(albumsDomain))
	}
	return result
}

func AlbumToResponseFromDomain(albumDomain models.Album) responses.AlbumResponse {
	return responses.AlbumResponse{
		Id:        albumDomain.Id,
		Title:     albumDomain.Title,
		PreviewId: albumDomain.PreviewId,
		OwnerId:   albumDomain.OwnerId,
		Files:     FileSliceToResponseFromDomain(&albumDomain.Files),
	}
}
