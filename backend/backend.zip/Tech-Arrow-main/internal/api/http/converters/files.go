package converters

import (
	"github.com/BobrePatre/Tech-Arrow/internal/api/http/datatransfers/responses"
	"github.com/BobrePatre/Tech-Arrow/internal/models"
)

func FileSliceToResponseFromDomain(files *[]models.File) *[]responses.FileResponse {
	var result []responses.FileResponse
	for _, file := range *files {
		f := FileToResponseFromDomain(&file)
		f.Metadata = MetadataToReponseFromDomain(*file.Metadata)
		result = append(result, *f)
	}
	return &result
}

func FileToResponseFromDomain(file *models.File) *responses.FileResponse {
	return &responses.FileResponse{
		Id:      file.Id,
		OwnerId: file.OwnerId,
	}
}

func MetadataToReponseFromDomain(metadata models.FileMetadata) *responses.FileMetadata {
	return &responses.FileMetadata{
		Id:            metadata.Id,
		Size:          metadata.Size,
		FileType:      metadata.FileType,
		FileExtention: metadata.FileExtention,
		Tags:          nil,
	}
}
